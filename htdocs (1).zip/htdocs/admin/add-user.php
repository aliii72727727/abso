<?php
session_start();
require_once '../app/firebase.php';

if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true){
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $rank = $_POST['rank'] ?? 'MEMBER';
    $country = $_POST['country'] ?? '';
    $coins = intval($_POST['coins'] ?? 0);
    
    // التحقق من المدخلات
    if(empty($name) || empty($email) || empty($password)){
        $error = 'جميع الحقول المطلوبة يجب تعبئتها';
    }elseif($password !== $confirmPassword){
        $error = 'كلمتا المرور غير متطابقتين';
    }elseif(strlen($password) < 6){
        $error = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';
    }else{
        // إنشاء معرف فريد للمستخدم
        $uid = 'user_' . time() . '_' . rand(1000, 9999);
        $customID = 'IRQ' . strtoupper(substr(md5($email . time()), 0, 8));
        
        // بيانات المستخدم
        $userData = [
            'uid' => $uid,
            'name' => $name,
            'email' => $email,
            'password' => md5($password), // في الواقع يجب استخدام hash أقوى
            'rank' => $rank,
            'country' => $country,
            'customID' => $customID,
            'coins' => $coins,
            'lastLogin' => date('Y-m-d H:i:s'),
            'createdAt' => date('Y-m-d H:i:s')
        ];
        
        // حفظ في Firebase
        $result = $firebase->set("users/$uid", $userData);
        
        if($result){
            $success = 'تم إضافة المستخدم بنجاح!';
            // إعادة تعيين النموذج
            $_POST = [];
        }else{
            $error = 'حدث خطأ أثناء إضافة المستخدم';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة مستخدم - العراق كرافت</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --success: #27ae60;
            --danger: #e74c3c;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Tajawal', sans-serif;
            background: #f5f7fa;
            direction: rtl;
        }
        .dashboard {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 260px;
            background: var(--primary);
            color: white;
            position: fixed;
            height: 100vh;
        }
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-logo {
            font-size: 24px;
            font-weight: 900;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: 0.3s;
            border-right: 3px solid transparent;
        }
        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            color: white;
            border-right-color: var(--secondary);
        }
        .main-content {
            flex: 1;
            margin-right: 260px;
            padding: 20px;
        }
        .top-bar {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .section {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #ddd;
            border-radius: 6px;
            font-family: 'Tajawal';
            font-size: 14px;
            transition: 0.3s;
        }
        .form-control:focus {
            border-color: var(--secondary);
            outline: none;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Tajawal';
            font-weight: 600;
            transition: 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary {
            background: var(--secondary);
            color: white;
        }
        .btn-primary:hover {
            background: #2980b9;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">العراق كرافت</div>
            </div>
            <div class="sidebar-menu">
                <a href="dash.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>لوحة التحكم</span>
                </a>
                <a href="users.php" class="menu-item">
                    <i class="fas fa-users"></i>
                    <span>المستخدمين</span>
                </a>
                <a href="add-user.php" class="menu-item">
                    <i class="fas fa-user-plus"></i>
                    <span>إضافة مستخدم</span>
                </a>
                <a href="mods.php" class="menu-item">
                    <i class="fas fa-cube"></i>
                    <span>المودات</span>
                </a>
                <a href="stats.php" class="menu-item">
                    <i class="fas fa-chart-line"></i>
                    <span>إحصائيات</span>
                </a>
                <a href="logout.php" class="menu-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>تسجيل الخروج</span>
                </a>
            </div>
        </div>

        <div class="main-content">
            <div class="top-bar">
                <h1>إضافة مستخدم جديد</h1>
            </div>

            <div class="section">
                <?php if($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo $success; ?>
                </div>
                <?php endif; ?>
                
                <?php if($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error; ?>
                </div>
                <?php endif; ?>

                <form method="post" action="">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">الاسم الكامل *</label>
                            <input type="text" class="form-control" name="name" 
                                   value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">البريد الإلكتروني *</label>
                            <input type="email" class="form-control" name="email"
                                   value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">كلمة المرور *</label>
                            <input type="password" class="form-control" name="password" required minlength="6">
                        </div>
                        <div class="form-group">
                            <label class="form-label">تأكيد كلمة المرور *</label>
                            <input type="password" class="form-control" name="confirm_password" required minlength="6">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">الدولة</label>
                            <select class="form-control" name="country">
                                <option value="العراق">🇮🇶 العراق</option>
                                <option value="السعودية">🇸🇦 السعودية</option>
                                <option value="مصر">🇪🇬 مصر</option>
                                <option value="الجزائر">🇩🇿 الجزائر</option>
                                <option value="اخرى">🌍 أخرى</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">الرتبة</label>
                            <select class="form-control" name="rank">
                                <option value="MEMBER">عضو</option>
                                <option value="VIP">VIP</option>
                                <option value="ADMIN">مسؤول</option>
                                <option value="OWNER">مالك</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">العملات</label>
                        <input type="number" class="form-control" name="coins" 
                               value="<?php echo $_POST['coins'] ?? 100; ?>" min="0">
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> حفظ المستخدم
                        </button>
                        <a href="users.php" style="margin-right: 15px;">العودة إلى القائمة</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>