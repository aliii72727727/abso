<?php
session_start();
require_once '../app/firebase.php';

if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true){
    header('Location: index.php');
    exit;
}

if(!isset($_GET['uid'])){
    header('Location: users.php');
    exit;
}

$uid = $_GET['uid'];
$firebase->delete("users/$uid");

header('Location: users.php?deleted=1');
exit;
?>