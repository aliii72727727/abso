<?php
session_start();
require_once '../app/firebase.php';

if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true){
    header('Location: index.php');
    exit;
}

// جلب المستخدمين
$users = $firebase->get('users') ?: [];

// البحث والتصفية
$search = $_GET['search'] ?? '';
$filter = $_GET['filter'] ?? '';

if($search){
    $filteredUsers = [];
    foreach($users as $uid => $user){
        if(stripos($user['name'] ?? '', $search) !== false || 
           stripos($user['email'] ?? '', $search) !== false ||
           stripos($user['customID'] ?? '', $search) !== false){
            $filteredUsers[$uid] = $user;
        }
    }
    $users = $filteredUsers;
}

if($filter && in_array($filter, ['MEMBER', 'VIP', 'ADMIN', 'OWNER'])){
    $filteredUsers = [];
    foreach($users as $uid => $user){
        if(($user['rank'] ?? 'MEMBER') === $filter){
            $filteredUsers[$uid] = $user;
        }
    }
    $users = $filteredUsers;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المستخدمين - العراق كرافت</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --success: #27ae60;
            --danger: #e74c3c;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Tajawal', sans-serif;
            background: #f5f7fa;
            direction: rtl;
        }
        .dashboard {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 260px;
            background: var(--primary);
            color: white;
            position: fixed;
            height: 100vh;
        }
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-logo {
            font-size: 24px;
            font-weight: 900;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: 0.3s;
            border-right: 3px solid transparent;
        }
        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            color: white;
            border-right-color: var(--secondary);
        }
        .menu-item.active {
            background: rgba(255,255,255,0.15);
            color: white;
            border-right-color: var(--secondary);
        }
        .main-content {
            flex: 1;
            margin-right: 260px;
            padding: 20px;
        }
        .top-bar {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .section {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .search-filter {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        .search-filter input,
        .search-filter select {
            padding: 10px 15px;
            border: 2px solid #ddd;
            border-radius: 6px;
            font-family: 'Tajawal';
            font-size: 14px;
        }
        .search-filter input {
            flex: 1;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Tajawal';
            font-weight: 600;
            transition: 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary { background: var(--secondary); color: white; }
        .btn-success { background: var(--success); color: white; }
        .btn-danger { background: var(--danger); color: white; }
        .btn-sm { padding: 5px 10px; font-size: 14px; }
        .table-container {
            overflow-x: auto;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }
        .data-table th {
            background: #f8f9fa;
            padding: 15px;
            text-align: right;
            font-weight: 700;
            border-bottom: 2px solid #dee2e6;
        }
        .data-table td {
            padding: 15px;
            border-bottom: 1px solid #dee2e6;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
        }
        .badge-member { background: #e3f2fd; color: #1976d2; }
        .badge-vip { background: #fff3e0; color: #f57c00; }
        .badge-admin { background: #fce4ec; color: #c2185b; }
        .badge-owner { background: #e8f5e9; color: #388e3c; }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">العراق كرافت</div>
            </div>
            <div class="sidebar-menu">
                <a href="dash.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>لوحة التحكم</span>
                </a>
                <a href="users.php" class="menu-item active">
                    <i class="fas fa-users"></i>
                    <span>المستخدمين</span>
                </a>
                <a href="add-user.php" class="menu-item">
                    <i class="fas fa-user-plus"></i>
                    <span>إضافة مستخدم</span>
                </a>
                <a href="mods.php" class="menu-item">
                    <i class="fas fa-cube"></i>
                    <span>المودات</span>
                </a>
                <a href="stats.php" class="menu-item">
                    <i class="fas fa-chart-line"></i>
                    <span>إحصائيات</span>
                </a>
                <a href="ss.php" class="menu-item">
                    <i class="fas fa-history"></i>
                    <span>السجلات</span>
                </a>
                <a href="logout.php" class="menu-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>تسجيل الخروج</span>
                </a>
            </div>
        </div>

        <div class="main-content">
            <div class="top-bar">
                <h1>إدارة المستخدمين</h1>
            </div>

            <div class="section">
                <div class="section-header">
                    <h2>قائمة المستخدمين</h2>
                    <a href="add-user.php" class="btn btn-success">
                        <i class="fas fa-plus"></i> إضافة مستخدم
                    </a>
                </div>

                <div class="search-filter">
                    <input type="text" id="searchInput" placeholder="ابحث عن مستخدم..." 
                           value="<?php echo htmlspecialchars($search); ?>"
                           onkeyup="if(event.keyCode===13) searchUsers()">
                    <select id="filterSelect" onchange="filterUsers()">
                        <option value="">جميع الرتب</option>
                        <option value="MEMBER" <?php echo $filter === 'MEMBER' ? 'selected' : ''; ?>>عضو</option>
                        <option value="VIP" <?php echo $filter === 'VIP' ? 'selected' : ''; ?>>VIP</option>
                        <option value="ADMIN" <?php echo $filter === 'ADMIN' ? 'selected' : ''; ?>>مسؤول</option>
                        <option value="OWNER" <?php echo $filter === 'OWNER' ? 'selected' : ''; ?>>مالك</option>
                    </select>
                    <button class="btn btn-primary" onclick="searchUsers()">
                        <i class="fas fa-search"></i> بحث
                    </button>
                </div>

                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>الاسم</th>
                                <th>البريد الإلكتروني</th>
                                <th>الدولة</th>
                                <th>الرتبة</th>
                                <th>العملات</th>
                                <th>آخر دخول</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(empty($users)): ?>
                            <tr>
                                <td colspan="8" style="text-align: center; padding: 50px;">
                                    <i class="fas fa-users-slash fa-2x" style="color: #ccc; margin-bottom: 10px;"></i>
                                    <p>لا توجد مستخدمين</p>
                                </td>
                            </tr>
                            <?php else: ?>
                            <?php foreach($users as $uid => $user): ?>
                            <tr>
                                <td><?php echo substr($uid, 0, 8) . '...'; ?></td>
                                <td><?php echo htmlspecialchars($user['name'] ?? 'غير معروف'); ?></td>
                                <td><?php echo htmlspecialchars($user['email'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($user['country'] ?? 'غير معروفة'); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo strtolower($user['rank'] ?? 'member'); ?>">
                                        <?php echo $user['rank'] ?? 'MEMBER'; ?>
                                    </span>
                                </td>
                                <td><?php echo $user['coins'] ?? 0; ?></td>
                                <td><?php echo $user['lastLogin'] ?? 'غير معروف'; ?></td>
                                <td>
                                    <a href="edit-user.php?uid=<?php echo $uid; ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button onclick="deleteUser('<?php echo $uid; ?>', '<?php echo htmlspecialchars($user['name']); ?>')" 
                                            class="btn btn-sm btn-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        function searchUsers(){
            const search = document.getElementById('searchInput').value;
            const filter = document.getElementById('filterSelect').value;
            window.location.href = `users.php?search=${encodeURIComponent(search)}&filter=${filter}`;
        }

        function filterUsers(){
            const filter = document.getElementById('filterSelect').value;
            const search = document.getElementById('searchInput').value;
            window.location.href = `users.php?search=${encodeURIComponent(search)}&filter=${filter}`;
        }

        function deleteUser(uid, name){
            if(confirm(`هل أنت متأكد من حذف المستخدم "${name}"؟ هذا الإجراء لا يمكن التراجع عنه.`)){
                window.location.href = `delete-user.php?uid=${uid}`;
            }
        }
    </script>
</body>
</html>