<?php
// إعدادات Firebase الخاصة بك
define('FIREBASE_API_KEY', 'AIzaSyDgqgIdXgZflmPT4z3IcaIzg6f7BxLEvyE');
define('FIREBASE_DATABASE_URL', 'https://matrixmodadd-default-rtdb.asia-southeast1.firebasedatabase.app/');
?>