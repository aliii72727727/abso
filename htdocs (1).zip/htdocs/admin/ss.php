<?php
session_start();
require_once '../app/firebase.php';

if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true){
    header('Location: index.php');
    exit;
}

// جلب السجلات من Firebase
$logs = $firebase->get('logs') ?: [];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سجلات النظام - العراق كرافت</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Tajawal', sans-serif;
            background: #f5f7fa;
            direction: rtl;
        }
        .dashboard {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 260px;
            background: var(--primary);
            color: white;
            position: fixed;
            height: 100vh;
        }
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-logo {
            font-size: 24px;
            font-weight: 900;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: 0.3s;
            border-right: 3px solid transparent;
        }
        .menu-item:hover, .menu-item.active {
            background: rgba(255,255,255,0.1);
            color: white;
            border-right-color: var(--secondary);
        }
        .main-content {
            flex: 1;
            margin-right: 260px;
            padding: 20px;
        }
        .top-bar {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .section {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .table-container {
            overflow-x: auto;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        .data-table th {
            background: #f8f9fa;
            padding: 15px;
            text-align: right;
            font-weight: 700;
            border-bottom: 2px solid #dee2e6;
        }
        .data-table td {
            padding: 15px;
            border-bottom: 1px solid #dee2e6;
        }
        .log-type {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
        }
        .log-login { background: #e3f2fd; color: #1976d2; }
        .log-register { background: #e8f5e9; color: #388e3c; }
        .log-mod { background: #fff3e0; color: #f57c00; }
        .log-system { background: #f5f5f5; color: #616161; }
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Tajawal';
            font-weight: 600;
            transition: 0.3s;
        }
        .btn-danger {
            background: #e74c3c;
            color: white;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">العراق كرافت</div>
            </div>
            <div class="sidebar-menu">
                <a href="dash.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>لوحة التحكم</span>
                </a>
                <a href="users.php" class="menu-item">
                    <i class="fas fa-users"></i>
                    <span>المستخدمين</span>
                </a>
                <a href="mods.php" class="menu-item">
                    <i class="fas fa-cube"></i>
                    <span>المودات</span>
                </a>
                <a href="stats.php" class="menu-item">
                    <i class="fas fa-chart-line"></i>
                    <span>إحصائيات</span>
                </a>
                <a href="ss.php" class="menu-item active">
                    <i class="fas fa-history"></i>
                    <span>السجلات</span>
                </a>
                <a href="logout.php" class="menu-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>تسجيل الخروج</span>
                </a>
            </div>
        </div>

        <div class="main-content">
            <div class="top-bar">
                <h1>سجلات النظام</h1>
            </div>

            <div class="section">
                <div class="section-header">
                    <h2>سجلات الأنشطة</h2>
                    <form method="post" style="display: inline;">
                        <button type="submit" name="clear_logs" class="btn btn-danger"
                                onclick="return confirm('هل أنت متأكد من مسح جميع السجلات؟')">
                            <i class="fas fa-trash"></i> مسح السجلات
                        </button>
                    </form>
                </div>

                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>التاريخ</th>
                                <th>المستخدم</th>
                                <th>النوع</th>
                                <th>العنوان</th>
                                <th>التفاصيل</th>
                                <th>IP</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(empty($logs)): ?>
                            <tr>
                                <td colspan="6" style="text-align: center; padding: 50px;">
                                    <i class="fas fa-history fa-2x" style="color: #ccc; margin-bottom: 10px;"></i>
                                    <p>لا توجد سجلات</p>
                                </td>
                            </tr>
                            <?php else: ?>
                            <?php 
                            // عكس المصفوفة لعرض الأحدث أولاً
                            $logs = array_reverse($logs);
                            foreach($logs as $log):
                                $typeClass = 'log-system';
                                switch($log['type'] ?? ''){
                                    case 'login': $typeClass = 'log-login'; break;
                                    case 'register': $typeClass = 'log-register'; break;
                                    case 'mod': $typeClass = 'log-mod'; break;
                                }
                            ?>
                            <tr>
                                <td><?php echo $log['timestamp'] ?? 'غير معروف'; ?></td>
                                <td><?php echo htmlspecialchars($log['user'] ?? 'النظام'); ?></td>
                                <td>
                                    <span class="log-type <?php echo $typeClass; ?>">
                                        <?php echo $log['type'] ?? 'system'; ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($log['action'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($log['details'] ?? ''); ?></td>
                                <td><?php echo $log['ip'] ?? 'غير معروف'; ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>