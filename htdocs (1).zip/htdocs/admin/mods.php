<?php
session_start();
require_once '../app/firebase.php';

if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true){
    header('Location: index.php');
    exit;
}

// جلب المودات
$mods = $firebase->get('mods') ?: [];

// حذف مود
if(isset($_GET['delete'])){
    $modId = $_GET['delete'];
    $firebase->delete("mods/$modId");
    header('Location: mods.php?deleted=1');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المودات - العراق كرافت</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --success: #27ae60;
            --danger: #e74c3c;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Tajawal', sans-serif;
            background: #f5f7fa;
            direction: rtl;
        }
        .dashboard {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 260px;
            background: var(--primary);
            color: white;
            position: fixed;
            height: 100vh;
        }
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-logo {
            font-size: 24px;
            font-weight: 900;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: 0.3s;
            border-right: 3px solid transparent;
        }
        .menu-item:hover, .menu-item.active {
            background: rgba(255,255,255,0.1);
            color: white;
            border-right-color: var(--secondary);
        }
        .main-content {
            flex: 1;
            margin-right: 260px;
            padding: 20px;
        }
        .top-bar {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .section {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Tajawal';
            font-weight: 600;
            transition: 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary { background: var(--secondary); color: white; }
        .btn-success { background: var(--success); color: white; }
        .btn-danger { background: var(--danger); color: white; }
        .btn-sm { padding: 5px 10px; font-size: 14px; }
        .table-container {
            overflow-x: auto;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }
        .data-table th {
            background: #f8f9fa;
            padding: 15px;
            text-align: right;
            font-weight: 700;
            border-bottom: 2px solid #dee2e6;
        }
        .data-table td {
            padding: 15px;
            border-bottom: 1px solid #dee2e6;
            vertical-align: middle;
        }
        .mod-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #c3e6cb;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">العراق كرافت</div>
            </div>
            <div class="sidebar-menu">
                <a href="dash.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>لوحة التحكم</span>
                </a>
                <a href="users.php" class="menu-item">
                    <i class="fas fa-users"></i>
                    <span>المستخدمين</span>
                </a>
                <a href="mods.php" class="menu-item active">
                    <i class="fas fa-cube"></i>
                    <span>المودات</span>
                </a>
                <a href="stats.php" class="menu-item">
                    <i class="fas fa-chart-line"></i>
                    <span>إحصائيات</span>
                </a>
                <a href="ss.php" class="menu-item">
                    <i class="fas fa-history"></i>
                    <span>السجلات</span>
                </a>
                <a href="logout.php" class="menu-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>تسجيل الخروج</span>
                </a>
            </div>
        </div>

        <div class="main-content">
            <div class="top-bar">
                <h1>إدارة المودات</h1>
            </div>

            <?php if(isset($_GET['deleted'])): ?>
            <div class="alert-success">
                <i class="fas fa-check-circle"></i> تم حذف المود بنجاح
            </div>
            <?php endif; ?>

            <div class="section">
                <div class="section-header">
                    <h2>قائمة المودات</h2>
                    <a href="add-mod.php" class="btn btn-success">
                        <i class="fas fa-plus"></i> إضافة مود
                    </a>
                </div>

                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>الصورة</th>
                                <th>اسم المود</th>
                                <th>الإصدار</th>
                                <th>الرابط</th>
                                <th>التصنيف</th>
                                <th>التاريخ</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(empty($mods)): ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 50px;">
                                    <i class="fas fa-cube fa-2x" style="color: #ccc; margin-bottom: 10px;"></i>
                                    <p>لا توجد مودات</p>
                                </td>
                            </tr>
                            <?php else: ?>
                            <?php foreach($mods as $modId => $mod): ?>
                            <tr>
                                <td>
                                    <?php if(isset($mod['image'])): ?>
                                    <img src="<?php echo htmlspecialchars($mod['image']); ?>" 
                                         alt="صورة المود" class="mod-image">
                                    <?php else: ?>
                                    <div style="width:60px; height:60px; background:#eee; border-radius:8px; display:flex; align-items:center; justify-content:center;">
                                        <i class="fas fa-cube" style="color:#999;"></i>
                                    </div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($mod['name'] ?? 'غير معروف'); ?></td>
                                <td><?php echo htmlspecialchars($mod['version'] ?? ''); ?></td>
                                <td>
                                    <a href="<?php echo htmlspecialchars($mod['link'] ?? '#'); ?>" 
                                       target="_blank" class="btn btn-sm btn-primary">
                                        <i class="fas fa-download"></i> تحميل
                                    </a>
                                </td>
                                <td><?php echo htmlspecialchars($mod['category'] ?? 'عام'); ?></td>
                                <td><?php echo $mod['timestamp'] ?? 'غير معروف'; ?></td>
                                <td>
                                    <a href="edit-mod.php?id=<?php echo $modId; ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button onclick="deleteMod('<?php echo $modId; ?>', '<?php echo htmlspecialchars($mod['name']); ?>')" 
                                            class="btn btn-sm btn-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        function deleteMod(id, name){
            if(confirm(`هل أنت متأكد من حذف المود "${name}"؟`)){
                window.location.href = `mods.php?delete=${id}`;
            }
        }
    </script>
</body>
</html>