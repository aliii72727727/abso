<?php
session_start();
require_once '../app/firebase.php';

if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true){
    header('Location: index.php');
    exit;
}

// جلب البيانات
$users = $firebase->get('users') ?: [];
$mods = $firebase->get('mods') ?: [];

// إحصائيات
$totalUsers = count($users);
$totalMods = count($mods);
$vipUsers = 0;
$adminUsers = 0;
$totalCoins = 0;
$todayUsers = 0;

if($users){
    foreach($users as $user){
        $totalCoins += $user['coins'] ?? 0;
        if(($user['rank'] ?? 'MEMBER') === 'VIP') $vipUsers++;
        if(($user['rank'] ?? 'MEMBER') === 'ADMIN' || ($user['rank'] ?? '') === 'OWNER') $adminUsers++;
        if(isset($user['lastLogin']) && date('Y-m-d') === date('Y-m-d', strtotime($user['lastLogin']))) $todayUsers++;
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الإحصائيات - العراق كرافت</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --success: #27ae60;
            --danger: #e74c3c;
            --warning: #f39c12;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Tajawal', sans-serif;
            background: #f5f7fa;
            direction: rtl;
        }
        .dashboard {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 260px;
            background: var(--primary);
            color: white;
            position: fixed;
            height: 100vh;
        }
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-logo {
            font-size: 24px;
            font-weight: 900;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: 0.3s;
            border-right: 3px solid transparent;
        }
        .menu-item:hover, .menu-item.active {
            background: rgba(255,255,255,0.1);
            color: white;
            border-right-color: var(--secondary);
        }
        .main-content {
            flex: 1;
            margin-right: 260px;
            padding: 20px;
        }
        .top-bar {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid var(--secondary);
        }
        .stat-card.success { border-top-color: var(--success); }
        .stat-card.warning { border-top-color: var(--warning); }
        .stat-card.danger { border-top-color: var(--danger); }
        .stat-value {
            font-size: 32px;
            font-weight: 900;
            margin-bottom: 10px;
        }
        .stat-label {
            color: #666;
            font-size: 14px;
        }
        .chart-container {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .chart-title {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 20px;
            color: var(--primary);
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">العراق كرافت</div>
            </div>
            <div class="sidebar-menu">
                <a href="dash.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>لوحة التحكم</span>
                </a>
                <a href="users.php" class="menu-item">
                    <i class="fas fa-users"></i>
                    <span>المستخدمين</span>
                </a>
                <a href="mods.php" class="menu-item">
                    <i class="fas fa-cube"></i>
                    <span>المودات</span>
                </a>
                <a href="stats.php" class="menu-item active">
                    <i class="fas fa-chart-line"></i>
                    <span>إحصائيات</span>
                </a>
                <a href="logout.php" class="menu-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>تسجيل الخروج</span>
                </a>
            </div>
        </div>

        <div class="main-content">
            <div class="top-bar">
                <h1>الإحصائيات</h1>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value"><?php echo $totalUsers; ?></div>
                    <div class="stat-label">إجمالي المستخدمين</div>
                    <div style="margin-top: 10px; font-size: 12px; color: #666;">
                        <i class="fas fa-user-plus" style="color: var(--success);"></i>
                        +<?php echo $todayUsers; ?> اليوم
                    </div>
                </div>
                <div class="stat-card success">
                    <div class="stat-value"><?php echo $vipUsers; ?></div>
                    <div class="stat-label">مستخدمين VIP</div>
                </div>
                <div class="stat-card warning">
                    <div class="stat-value"><?php echo number_format($totalCoins); ?></div>
                    <div class="stat-label">إجمالي العملات</div>
                </div>
                <div class="stat-card danger">
                    <div class="stat-value"><?php echo $totalMods; ?></div>
                    <div class="stat-label">عدد المودات</div>
                </div>
            </div>

            <div class="chart-container">
                <div class="chart-title">توزيع المستخدمين حسب الرتبة</div>
                <canvas id="rankChart" style="height: 300px;"></canvas>
            </div>

            <div class="chart-container">
                <div class="chart-title">إحصائيات المودات</div>
                <canvas id="modsChart" style="height: 300px;"></canvas>
            </div>
        </div>
    </div>

    <script>
        // بيانات الرتب
        const rankData = {
            member: <?php echo $totalUsers - $vipUsers - $adminUsers; ?>,
            vip: <?php echo $vipUsers; ?>,
            admin: <?php echo $adminUsers; ?>
        };

        // رسم توزيع الرتب
        const rankCtx = document.getElementById('rankChart').getContext('2d');
        new Chart(rankCtx, {
            type: 'pie',
            data: {
                labels: ['أعضاء', 'VIP', 'مسؤولين'],
                datasets: [{
                    data: [rankData.member, rankData.vip, rankData.admin],
                    backgroundColor: [
                        '#3498db',
                        '#f39c12',
                        '#e74c3c'
                    ],
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        rtl: true
                    }
                }
            }
        });

        // رسم إحصائيات المودات
        const modsCtx = document.getElementById('modsChart').getContext('2d');
        new Chart(modsCtx, {
            type: 'bar',
            data: {
                labels: ['المودات'],
                datasets: [{
                    label: 'إجمالي المودات',
                    data: [<?php echo $totalMods; ?>],
                    backgroundColor: '#27ae60'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>