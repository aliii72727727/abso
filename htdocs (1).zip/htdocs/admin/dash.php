<?php
session_start();
require_once '../app/firebase.php';

if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true){
    header('Location: index.php');
    exit;
}

// جلب البيانات من Firebase
$users = $firebase->get('users');
$mods = $firebase->get('mods');

// إحصائيات
$totalUsers = $users ? count($users) : 0;
$totalMods = $mods ? count($mods) : 0;
$vipUsers = 0;
$adminUsers = 0;
$todayUsers = 0;

if($users){
    foreach($users as $user){
        if(isset($user['rank']) && $user['rank'] === 'VIP') $vipUsers++;
        if(isset($user['rank']) && ($user['rank'] === 'ADMIN' || $user['rank'] === 'OWNER')) $adminUsers++;
        if(isset($user['lastLogin']) && date('Y-m-d') === date('Y-m-d', strtotime($user['lastLogin']))) $todayUsers++;
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم - العراق كرافت</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --success: #27ae60;
            --danger: #e74c3c;
            --warning: #f39c12;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Tajawal', sans-serif;
            background: #f5f7fa;
            color: var(--dark);
            direction: rtl;
        }
        .dashboard {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 260px;
            background: var(--primary);
            color: white;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-logo {
            font-size: 24px;
            font-weight: 900;
            color: white;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: 0.3s;
            border-right: 3px solid transparent;
        }
        .menu-item:hover, .menu-item.active {
            background: rgba(255,255,255,0.1);
            color: white;
            border-right-color: var(--secondary);
        }
        .menu-item i {
            margin-left: 10px;
            width: 20px;
            text-align: center;
        }
        .main-content {
            flex: 1;
            margin-right: 260px;
            padding: 20px;
        }
        .top-bar {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-top: 4px solid var(--secondary);
        }
        .stat-card.success { border-top-color: var(--success); }
        .stat-card.warning { border-top-color: var(--warning); }
        .stat-card.danger { border-top-color: var(--danger); }
        .stat-value {
            font-size: 32px;
            font-weight: 900;
            margin-bottom: 10px;
        }
        .stat-label {
            color: #666;
            font-size: 14px;
        }
        .section {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        .section-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--primary);
        }
        .table-container {
            overflow-x: auto;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        .data-table th {
            background: #f8f9fa;
            padding: 15px;
            text-align: right;
            font-weight: 700;
            border-bottom: 2px solid #dee2e6;
        }
        .data-table td {
            padding: 15px;
            border-bottom: 1px solid #dee2e6;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
        }
        .badge-member { background: #e3f2fd; color: #1976d2; }
        .badge-vip { background: #fff3e0; color: #f57c00; }
        .badge-admin { background: #fce4ec; color: #c2185b; }
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Tajawal';
            font-weight: 600;
            transition: 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary { background: var(--secondary); color: white; }
        .btn-sm { padding: 5px 10px; font-size: 14px; }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--secondary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- الشريط الجانبي -->
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">العراق كرافت</div>
            </div>
            <div class="sidebar-menu">
                <a href="dash.php" class="menu-item active">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>لوحة التحكم</span>
                </a>
                <a href="users.php" class="menu-item">
                    <i class="fas fa-users"></i>
                    <span>المستخدمين</span>
                    <span style="margin-right: auto;"><?php echo $totalUsers; ?></span>
                </a>
                <a href="add-user.php" class="menu-item">
                    <i class="fas fa-user-plus"></i>
                    <span>إضافة مستخدم</span>
                </a>
                <a href="mods.php" class="menu-item">
                    <i class="fas fa-cube"></i>
                    <span>المودات</span>
                    <span style="margin-right: auto;"><?php echo $totalMods; ?></span>
                </a>
                <a href="stats.php" class="menu-item">
                    <i class="fas fa-chart-line"></i>
                    <span>إحصائيات</span>
                </a>
                <a href="ss.php" class="menu-item">
                    <i class="fas fa-history"></i>
                    <span>السجلات</span>
                </a>
                <a href="settings.php" class="menu-item">
                    <i class="fas fa-cog"></i>
                    <span>الإعدادات</span>
                </a>
                <a href="logout.php" class="menu-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>تسجيل الخروج</span>
                </a>
            </div>
        </div>

        <!-- المحتوى الرئيسي -->
        <div class="main-content">
            <!-- الشريط العلوي -->
            <div class="top-bar">
                <div>
                    <h1 style="color: var(--primary);">مرحباً، <?php echo $_SESSION['admin_username']; ?></h1>
                    <p style="color: #666; margin-top: 5px;">لوحة تحكم إدارة العراق كرافت</p>
                </div>
                <div class="user-info">
                    <div class="user-avatar">
                        <?php echo strtoupper(substr($_SESSION['admin_username'], 0, 1)); ?>
                    </div>
                    <div>
                        <div style="font-weight: 700;"><?php echo $_SESSION['admin_username']; ?></div>
                        <div style="font-size: 12px; color: #666;">مدير النظام</div>
                    </div>
                </div>
            </div>

            <!-- بطاقات الإحصائيات -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value"><?php echo $totalUsers; ?></div>
                    <div class="stat-label">إجمالي المستخدمين</div>
                    <div style="margin-top: 10px; font-size: 12px; color: #666;">
                        <i class="fas fa-user-plus" style="color: var(--success);"></i>
                        +<?php echo $todayUsers; ?> اليوم
                    </div>
                </div>
                <div class="stat-card success">
                    <div class="stat-value"><?php echo $vipUsers; ?></div>
                    <div class="stat-label">مستخدمين VIP</div>
                </div>
                <div class="stat-card warning">
                    <div class="stat-value"><?php echo $totalMods; ?></div>
                    <div class="stat-label">المودات المضافة</div>
                </div>
                <div class="stat-card danger">
                    <div class="stat-value"><?php echo $adminUsers; ?></div>
                    <div class="stat-label">المسؤولين</div>
                </div>
            </div>

            <!-- آخر المستخدمين -->
            <div class="section">
                <div class="section-header">
                    <h2 class="section-title">آخر المستخدمين</h2>
                    <a href="users.php" class="btn btn-primary">عرض الكل</a>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>الاسم</th>
                                <th>البريد الإلكتروني</th>
                                <th>الدولة</th>
                                <th>الرتبة</th>
                                <th>آخر دخول</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if($users){
                                $recentUsers = array_slice(array_reverse($users), 0, 5);
                                foreach($recentUsers as $uid => $user):
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['name'] ?? 'غير معروف'); ?></td>
                                <td><?php echo htmlspecialchars($user['email'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($user['country'] ?? 'غير معروفة'); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo strtolower($user['rank'] ?? 'member'); ?>">
                                        <?php echo $user['rank'] ?? 'MEMBER'; ?>
                                    </span>
                                </td>
                                <td><?php echo $user['lastLogin'] ?? 'غير معروف'; ?></td>
                                <td>
                                    <a href="edit-user.php?uid=<?php echo $uid; ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; } ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- آخر المودات -->
            <div class="section">
                <div class="section-header">
                    <h2 class="section-title">آخر المودات</h2>
                    <a href="mods.php" class="btn btn-primary">عرض الكل</a>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>اسم المود</th>
                                <th>الإصدار</th>
                                <th>الصورة</th>
                                <th>الرابط</th>
                                <th>التاريخ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if($mods){
                                $recentMods = array_slice(array_reverse($mods), 0, 5);
                                foreach($recentMods as $mod):
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($mod['name'] ?? 'غير معروف'); ?></td>
                                <td><?php echo htmlspecialchars($mod['version'] ?? ''); ?></td>
                                <td>
                                    <?php if(isset($mod['image'])): ?>
                                    <img src="<?php echo htmlspecialchars($mod['image']); ?>" alt="صورة المود" style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px;">
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo htmlspecialchars($mod['link'] ?? '#'); ?>" target="_blank" class="btn btn-sm btn-primary">
                                        <i class="fas fa-download"></i>
                                    </a>
                                </td>
                                <td><?php echo $mod['timestamp'] ?? 'غير معروف'; ?></td>
                            </tr>
                            <?php endforeach; } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>