<?php
session_start();
require_once '../app/firebase.php';

if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true){
    header('Location: index.php');
    exit;
}

// جلب الإعدادات
$settings = $firebase->get('settings') ?: [];

$message = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $newSettings = [
        'site_name' => $_POST['site_name'] ?? 'العراق كرافت',
        'admin_email' => $_POST['admin_email'] ?? '',
        'default_coins' => intval($_POST['default_coins'] ?? 100),
        'vip_price' => intval($_POST['vip_price'] ?? 500),
        'maintenance' => isset($_POST['maintenance']) ? true : false,
        'enable_logs' => isset($_POST['enable_logs']) ? true : false
    ];
    
    $result = $firebase->set('settings', $newSettings);
    
    if($result){
        $message = '<div style="background:#d4edda; color:#155724; padding:15px; border-radius:8px; margin-bottom:20px;">
                    <i class="fas fa-check-circle"></i> تم حفظ الإعدادات بنجاح
                   </div>';
        $settings = $newSettings;
    }else{
        $message = '<div style="background:#f8d7da; color:#721c24; padding:15px; border-radius:8px; margin-bottom:20px;">
                    <i class="fas fa-exclamation-circle"></i> حدث خطأ أثناء حفظ الإعدادات
                   </div>';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الإعدادات - العراق كرافت</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Tajawal', sans-serif;
            background: #f5f7fa;
            direction: rtl;
        }
        .dashboard {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 260px;
            background: var(--primary);
            color: white;
            position: fixed;
            height: 100vh;
        }
        .sidebar-header {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-logo {
            font-size: 24px;
            font-weight: 900;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: 0.3s;
            border-right: 3px solid transparent;
        }
        .menu-item:hover, .menu-item.active {
            background: rgba(255,255,255,0.1);
            color: white;
            border-right-color: var(--secondary);
        }
        .main-content {
            flex: 1;
            margin-right: 260px;
            padding: 20px;
        }
        .top-bar {
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .section {
            background: white;
            border-radius: 10px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #ddd;
            border-radius: 6px;
            font-family: 'Tajawal';
            font-size: 14px;
            transition: 0.3s;
        }
        .form-control:focus {
            border-color: var(--secondary);
            outline: none;
        }
        .form-check {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .form-check-input {
            width: 20px;
            height: 20px;
        }
        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-family: 'Tajawal';
            font-weight: 600;
            transition: 0.3s;
        }
        .btn-primary {
            background: var(--secondary);
            color: white;
        }
        .btn-primary:hover {
            background: #2980b9;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">العراق كرافت</div>
            </div>
            <div class="sidebar-menu">
                <a href="dash.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>لوحة التحكم</span>
                </a>
                <a href="users.php" class="menu-item">
                    <i class="fas fa-users"></i>
                    <span>المستخدمين</span>
                </a>
                <a href="mods.php" class="menu-item">
                    <i class="fas fa-cube"></i>
                    <span>المودات</span>
                </a>
                <a href="stats.php" class="menu-item">
                    <i class="fas fa-chart-line"></i>
                    <span>إحصائيات</span>
                </a>
                <a href="settings.php" class="menu-item active">
                    <i class="fas fa-cog"></i>
                    <span>الإعدادات</span>
                </a>
                <a href="logout.php" class="menu-item">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>تسجيل الخروج</span>
                </a>
            </div>
        </div>

        <div class="main-content">
            <div class="top-bar">
                <h1>إعدادات النظام</h1>
            </div>

            <div class="section">
                <?php echo $message; ?>
                
                <form method="post" action="">
                    <div class="form-group">
                        <label class="form-label">اسم الموقع</label>
                        <input type="text" class="form-control" name="site_name" 
                               value="<?php echo htmlspecialchars($settings['site_name'] ?? 'العراق كرافت'); ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">البريد الإلكتروني للمسؤول</label>
                        <input type="email" class="form-control" name="admin_email"
                               value="<?php echo htmlspecialchars($settings['admin_email'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label class="form-label">العملات الافتراضية للمستخدم الجديد</label>
                        <input type="number" class="form-control" name="default_coins"
                               value="<?php echo $settings['default_coins'] ?? 100; ?>" min="0">
                    </div>

                    <div class="form-group">
                        <label class="form-label">سعر اشتراك VIP (بالعملات)</label>
                        <input type="number" class="form-control" name="vip_price"
                               value="<?php echo $settings['vip_price'] ?? 500; ?>" min="0">
                    </div>

                    <div class="form-group">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" name="maintenance" 
                                   id="maintenance" <?php echo ($settings['maintenance'] ?? false) ? 'checked' : ''; ?>>
                            <label class="form-label" for="maintenance" style="margin-bottom: 0;">
                                وضع الصيانة
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" name="enable_logs" 
                                   id="enable_logs" <?php echo ($settings['enable_logs'] ?? true) ? 'checked' : ''; ?>>
                            <label class="form-label" for="enable_logs" style="margin-bottom: 0;">
                                تفعيل سجلات النظام
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> حفظ الإعدادات
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>